const CACHE_NAME = "futureready-ai-v3";
const urlsToCache = [
  "./",
  "./index.html",
  "./manifest.json",
  "./assets/logo_menu.png",
  "./assets/icon-192.png",
  "./assets/icon-512.png",
  "./assets/dgt.png",
  "./assets/dgt2.png"
];

self.addEventListener("fetch", event => {
  event.respondWith(
    fetch(event.request)
      .then(response => {
        const responseClone = response.clone();

        caches.open(CACHE_NAME).then(cache => {
          cache.put(event.request, responseClone);
        });

        return response;
      })
      .catch(() => caches.match(event.request))
  );
});